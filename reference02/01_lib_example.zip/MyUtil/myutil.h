#ifndef MYUTIL_H
#define MYUTIL_H

#include "MyUtil_global.h"

class MYUTIL_EXPORT MyUtil
{
public:
    MyUtil();
    qint32 getSumValue(qint32 a, qint32 b);
};

#endif // MYUTIL_H
