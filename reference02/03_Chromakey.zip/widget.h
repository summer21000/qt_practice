#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:

    QImage m_sourceImg;
    QImage m_targetImg;
    QImage m_resultImg;

    int m_imgWidth;
    int m_imgHeight;
    int m_imgSize;

private:
    Ui::Widget *ui;
    void chromakeyProcess(QImage& sourceImage,
                          QImage& targetImage,
                          QImage& resultImage);
private slots:
    void slotChromakey();


};

#endif // WIDGET_H
