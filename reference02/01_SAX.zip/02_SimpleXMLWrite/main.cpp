#include <QCoreApplication>
#include <QFile>
#include <QXmlStreamWriter>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QByteArray data;

    QXmlStreamWriter writer(&data);
    writer.setAutoFormatting(true);

    writer.writeStartDocument();

        writer.writeStartElement("parent");

            writer.writeStartElement("childA");
                writer.writeAttribute("age", "31");
                writer.writeCharacters("김수현");
            writer.writeEndElement();

            writer.writeStartElement("childB");
                writer.writeAttribute("age", "41");
                writer.writeCharacters("이아영");
            writer.writeEndElement();

        writer.writeEndElement();

    writer.writeEndDocument();

    QFile file("d:/output.xml");
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    file.write(data.data());
    file.close();

    return a.exec();
}
