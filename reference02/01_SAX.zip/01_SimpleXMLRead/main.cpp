#include <QCoreApplication>
#include <QFile>
#include <QXmlStreamReader>
#include <QDebug>

void simpleReadXML(QFile *file)
{
    QXmlStreamReader reader(file);
    if (reader.readNextStartElement())
    {
        if (reader.name().toString() == "parent")
        {
            while(reader.readNextStartElement())
            {
                if(reader.name().toString() == "childA") {
                    int age = reader.attributes().value("age").toInt();
                    QString nameStr = reader.readElementText();
                    qDebug() << "AGE: " << age << " NAME: " << nameStr;
                }
            }
        }
    }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QFile file(":/simple.xml");
    file.open(QFile::ReadOnly | QFile::Text);

    simpleReadXML(&file);

    return a.exec();
}
