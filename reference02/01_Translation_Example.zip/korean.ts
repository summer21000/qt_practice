<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko_KR">
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.ui" line="14"/>
        <source>Widget</source>
        <translation>위젯</translation>
    </message>
    <message>
        <location filename="widget.ui" line="26"/>
        <source>Button</source>
        <translation>버튼</translation>
    </message>
    <message>
        <location filename="widget.ui" line="39"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="9"/>
        <source>Hello</source>
        <translation>안녕하세요</translation>
    </message>
</context>
</TS>
