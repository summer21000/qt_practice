#include "widget.h"

#include <QApplication>
#include <QTranslator>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 꼭 QApplication 하위에 위치할 것
    QTranslator translator;
    if(translator.load(":/Translator/korean.qm")) {
        QApplication::installTranslator(&translator);
    }

    Widget w;
    w.show();

    return a.exec();
}
