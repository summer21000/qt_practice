#include "myutil.h"

MyUtil::MyUtil()
{
}

qint32 MyUtil::getSumValue(qint32 a, qint32 b)
{
    //return a + b;
    return a * b;
}
