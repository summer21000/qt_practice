#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("라이브러리예제");

    m_myUtil = new MyUtil();

    connect(ui->pbtCalculation, SIGNAL(pressed()),
            this, SLOT(slot_pbtCalculation()));
}

void Widget::slot_pbtCalculation()
{
    qint32 aValue = ui->leAvalue->text().toInt();
    qint32 bValue = ui->leBvalue->text().toInt();

    qint32 sumValue = m_myUtil->getSumValue(aValue, bValue);

    QString retStr = QString("%1").arg(sumValue);
    ui->leResultValue->setText(retStr);
}

Widget::~Widget()
{
    delete ui;
}

