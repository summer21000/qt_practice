#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>

Widget::Widget(QWidget *parent) : QWidget(parent), ui(new Ui::Widget)
{
    ui->setupUi(this);
    connect(ui->pbtJSONParser, SIGNAL(pressed()), this, SLOT(slotPbtJSONParser()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::slotPbtJSONParser()
{
    QFile file(":/simple.json");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return;
    }
    QString data = file.readAll();
    file.close();

    ui->textEdit->clear();

    parseJSON(data);
}

void Widget::parseJSON(const QString &data)
{

    QJsonDocument jsonResponse = QJsonDocument::fromJson(data.toLocal8Bit());
    QJsonObject jsonObj = jsonResponse.object();

    QString timeStr = jsonObj["time"].toString();
    QString dateStr = jsonObj["date"].toString();

    QString successStr;
    if(jsonObj["success"].toBool() == true)
        successStr = QString("success : true");
    else
        successStr = QString("success : false");

    ui->textEdit->append(timeStr);
    ui->textEdit->append(dateStr);
    ui->textEdit->append(successStr);

    QJsonArray jsonArray = jsonObj["properties"].toArray();

    foreach (const QJsonValue & value, jsonArray)
    {
        QJsonObject obj = value.toObject();

        int id           = obj["ID"].toInt();
        QString property = obj["PropertyName"].toString();

        QString arrayData;
        arrayData = QString("ID : %1 , Property Name : %2")
                                .arg(id).arg(property);

        ui->textEdit->append(arrayData);
    }
}



