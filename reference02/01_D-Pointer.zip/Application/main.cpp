#include <QCoreApplication>
#include <QDebug>

#include "myclass.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    MyClass myclass;

    myclass.printValue();

    return a.exec();
}
